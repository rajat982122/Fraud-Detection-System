from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
import pymysql
from fastapi import Body, FastAPI, HTTPException

MODEL_PATH = Path(os.getenv("MODEL_PATH", "artifacts/fraud_model.pkl"))
PREPROCESSOR_PATH = Path(os.getenv("PREPROCESSOR_PATH", "artifacts/preprocessor.pkl"))

MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "fraud_db")
MYSQL_USER = os.getenv("MYSQL_USER", "fraud_user")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "fraud_pass")

app = FastAPI(title="Real-Time Fraud Detection API", version="1.0.0")

MODEL: Any | None = None
PREPROCESSOR: dict[str, Any] | None = None
MODEL_LOAD_ERROR: str | None = None


def load_artifacts() -> None:
    global MODEL, PREPROCESSOR, MODEL_LOAD_ERROR

    try:
        MODEL = joblib.load(MODEL_PATH)
        PREPROCESSOR = joblib.load(PREPROCESSOR_PATH)
        MODEL_LOAD_ERROR = None
    except FileNotFoundError:
        MODEL = None
        PREPROCESSOR = None
        MODEL_LOAD_ERROR = (
            "Model artifacts are missing. Run train.py first so the API can load the model."
        )


def preprocess_transaction(transaction: dict[str, Any], preprocessor: dict[str, Any]) -> pd.DataFrame:
    feature_columns = preprocessor["feature_columns"]
    categorical_columns = set(preprocessor["categorical_columns"])
    encoders = preprocessor["encoders"]
    fill_value = preprocessor["fill_value"]

    processed_row: dict[str, float] = {}

    for column in feature_columns:
        value = transaction.get(column, fill_value)
        if value in (None, "") or pd.isna(value):
            value = fill_value

        if column in categorical_columns:
            mapping_info = encoders[column]
            mapping = mapping_info["mapping"]
            default_value = mapping_info["default_value"]
            processed_row[column] = float(mapping.get(str(value), default_value))
        else:
            try:
                processed_row[column] = float(value)
            except (TypeError, ValueError):
                processed_row[column] = float(fill_value)

    return pd.DataFrame([processed_row], columns=feature_columns).astype("float32")


def get_mysql_connection() -> pymysql.connections.Connection:
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        autocommit=False,
        cursorclass=pymysql.cursors.DictCursor,
    )


def save_prediction(
    connection: pymysql.connections.Connection,
    txn_id: int,
    amount: float,
    is_fraud: int,
    fraud_probability: float,
) -> None:
    query = """
        INSERT INTO fraud_predictions (txn_id, amount, is_fraud, fraud_prob, processed_at)
        VALUES (%s, %s, %s, %s, %s)
    """
    with connection.cursor() as cursor:
        cursor.execute(
            query,
            (
                txn_id,
                amount,
                is_fraud,
                fraud_probability,
                datetime.utcnow(),
            ),
        )
    connection.commit()


@app.on_event("startup")
def startup_event() -> None:
    load_artifacts()


@app.get("/")
def root() -> dict[str, Any]:
    return {
        "message": "Fraud detection API is running.",
        "model_ready": MODEL is not None,
        "details": MODEL_LOAD_ERROR or "Model loaded successfully.",
    }


@app.post("/predict")
def predict(transaction: dict[str, Any] = Body(...)) -> dict[str, Any]:
    if MODEL is None or PREPROCESSOR is None:
        raise HTTPException(status_code=503, detail=MODEL_LOAD_ERROR)

    feature_frame = preprocess_transaction(transaction, PREPROCESSOR)
    threshold = float(PREPROCESSOR.get("threshold", 0.5))
    id_column = PREPROCESSOR.get("id_column", "TransactionID")

    fraud_probability = float(MODEL.predict_proba(feature_frame)[0][1])
    is_fraud = int(fraud_probability > threshold)
    txn_id = int(transaction.get(id_column) or int(datetime.utcnow().timestamp() * 1_000_000))
    amount = float(transaction.get("TransactionAmt") or 0.0)

    connection = get_mysql_connection()
    try:
        save_prediction(
            connection=connection,
            txn_id=txn_id,
            amount=amount,
            is_fraud=is_fraud,
            fraud_probability=fraud_probability,
        )
    finally:
        connection.close()

    return {
        "txn_id": txn_id,
        "is_fraud": is_fraud,
        "fraud_probability": round(fraud_probability, 6),
        "threshold": threshold,
    }


@app.get("/stats")
def stats() -> dict[str, Any]:
    connection = get_mysql_connection()
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    COUNT(*) AS total_transactions,
                    COALESCE(SUM(is_fraud), 0) AS fraud_count,
                    COALESCE(ROUND((SUM(is_fraud) / NULLIF(COUNT(*), 0)) * 100, 2), 0) AS fraud_rate
                FROM fraud_predictions
                """
            )
            result = cursor.fetchone() or {}
    finally:
        connection.close()

    return {
        "total_transactions": int(result.get("total_transactions", 0) or 0),
        "fraud_count": int(result.get("fraud_count", 0) or 0),
        "fraud_rate_percent": float(result.get("fraud_rate", 0) or 0),
    }
